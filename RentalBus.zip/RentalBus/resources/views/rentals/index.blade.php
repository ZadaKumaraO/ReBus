@extends('layout.main')

@section('title', 'Search Result')

@section('container')
	<div class="container">
		<div class="row">
			<div class="col-6">
				<h1 class="mt-3 ">Hasil Pencarian</h1>
				
				<!--<a href="/drivers/create" class="btn btn-primary my-3" > Absen Supir </a>-->
				<!--memunculkan status setelah ditambahkan-->
				@if (session('status'))
    				<div class="alert alert-success">
        					{{ session('status') }}
   					 </div>
				@endif
				
				<ul class="list-group">
					@foreach($rentals as $rental)
				  	<li class="list-group-item d-flex justify-content-between align-items-center">
				    	{{ $rental->nama_bus }}

				    	<!--<a href="/students/1" class="badge badge-info">detail</a> nanti pas mencet detail yang keluar yg id nya 1 walaupun mencetnya detail untuk orang id ke 2 sehingga salah-->

				    	<a href="/students/{{ $rental->id }}" class="badge badge-info">detail</a>
				  	</li>
				  	@endforeach
				</ul>
			</div>
		</div>
    </div>
@endsection