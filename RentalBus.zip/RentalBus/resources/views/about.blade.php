@extends('layout.main')

@section('title', 'Tentang Kita')

@section('container')
{{-- Zada --}}
<div class="row no-gutters">
    <div class="card col-md-3 d-inline-block" style="width: 18rem;">
        <img class="card-img-top" src="{{ asset('zada.jpg') }}" alt="Card image cap">
        <div class="card-body">
          <h5 class="card-title">Nama: Zada Kumara Owena</h5>
          <h5 class="card-title">NIM: 18523132</h5>
          <h5 class="card-title">Kelas: C</h5>
        </div>
    </div>

{{-- Yusuf --}}
    <div class="card col-md-3 d-inline-block" style="width: 18rem;">
      <img class="card-img-top" src="{{ asset('yusuf.jpg') }}" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title">Nama: Muhammad Yusuf Imaddudin</h5>
        <h5 class="card-title">NIM: 18523250 </h5>
        <h5 class="card-title">Kelas: C</h5>
      </div>
    </div>

{{-- Dani --}}
    <div class="card col-md-3 d-inline-block" style="width: 18rem;">
      <img class="card-img-top" src="{{ asset('dani.jpg') }}" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title">Nama: Oke Setya Chandra Rahmadani</h5>
        <h5 class="card-title">NIM: 18523075</h5>
        <h5 class="card-title">Kelas: C</h5>
      </div>
    </div>

{{-- Fikri --}}
    <div class="card col-md-3 d-inline-block" style="width: 18rem;">
      <img class="card-img-top" src="{{ asset('fikri.jpg') }}" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title">Nama: Muhammad Fikri Saliim</h5>
        <h5 class="card-title">NIM: 18523061</h5>
        <h5 class="card-title">Kelas: C</h5>
      </div>
    </div>

@endsection
</html>