@extends('layout.main')

@section('title', 'Detail Bus')

@section('container')
<div class="container">
	<div class="card w-100 h-100">
	  <div class="row no-gutters">
	    <div class="col-md-4">
	    	{{-- kok pake asset knp? --}}
	      <img src="{{ asset($order->tujuan->foto) }}" class="card-img h-100 w-100" alt="..." style="object-fit: cover">
	    </div>
	    <div class="col-md-8">
	      <div class="card-body">
	        <h5 class="card-title">Nama Bus: {{ $order->tujuan->nama_bus }}</h5>
	        <h5 class="card-title">Nama Sopir: {{ $order->tujuan->nama_sopir }}</h5>
	        <h5 class="card-title">Harga:Rp. {{ $order->tujuan->harga }}/kursi </h5>
	        <h5 class="card-title">Jumlah Kursi: {{ $order->tujuan->jum_kursi }}</h5>
	        {{-- <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p> --}}
	        <p class="card-text"><small class="text-muted">Tanggal: {{ $order->tanggal }}</small></p>
	      </div>
	    </div>
	  </div>
	</div>
</div>

@endsection