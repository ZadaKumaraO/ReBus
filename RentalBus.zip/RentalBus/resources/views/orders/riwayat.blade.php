@extends('layout.main')

@section('title', 'Pesanan Saya')

@section('container')

	{{-- Membuat beri penilaian button hilang setelah di submit --}}
	<script type="text/javascript">
		// $(document).ready(function()
		// {
		// 	$("#hapus-button").click(function() 
		// 		{
		// 			$("#ratingbutton").hide();
		// 		});
		// });

	</script>

	<div class="container">
		<div class="row">
			<div class="col-10">
				<h1 class="mt-2">Pesanan Saya</h1>

				<table class="table">
				<thead class="thead-dark">
					<tr>
						<th scope="col">No.Pesanan</th>
						<th scope="col">Tujuan</th>
						<th scope="col">Nama Bus</th>
						<th scope="col">Harga</th>
						<th scope="col">Tanggal</th>
						<th scope="col">Jumlah Kursi  yang Dipesan </th>
						<th scope="col">Rating</th>
						<th scope="col">Aksi</th>
					</tr>
				</thead>
				<tbody>
					<!-- mengambil data dari tabel (variable $mahasiswa di singkat jadi $mhs)-->
					@foreach($orders as $order)
					<tr>
						<!-- loop-> iteration pengganti int++ (biar nomor otomatis bertambah)-->
						<th scope="row">{{ $order -> id }}{{-- {{ $loop->iteration }} --}}</th>
						<td>{{ $order -> tujuan -> tujuan }}</td>
						<td>{{ $order-> tujuan -> nama_bus }}</td>
						<td>{{ $order -> harga }}</td>
						<td>{{ $order -> tanggal }}</td>
						<td>{{ $order -> jum_kursi_pesan }}</td>
						<td>{{ $order -> rating }}</td>
						<td>
							{{-- Tombol Detail Pesanan --}}
							<a class="badge badge-info" href="/pesan/detail/{{ $order->id }}">Detail</a>

							{{-- JIKA BELUM DIRATING --}}
							@if(is_null($order->rating))

							{{-- Tombol Batal Pesan --}}

							<button class="badge badge-danger" type="button" data-toggle="modal" data-target="#modal-hapus-{{ $order->id }}">Batalkan Pesanan</button>

							{{-- Tombol Rating Pesan --}}

							
							<button class="badge badge-success" type="button" data-toggle="modal" data-target="#modal-rating-{{ $order->id }}">Beri Penilaian</button>
							
							{{-- JIKA SUDAH DIRATING --}}
							@else
							<form name="form-batal" id="form-batal" action="/pesan/hapus/{{ $order -> id }}" method="POST">

							<button class="badge badge-secondary" type="button" disabled>Pesanan Telah Selesai</button>
							<button class="badge badge-danger" type="submit">Hapus Riwayat Pesan</button>

							@endif

							<form name="form-rating" id="form-rating" action="/pesan/rating/{{ $order -> id }}" method="POST">
								@csrf
								<!-- Modal -->
								<div class="modal fade" id="modal-rating-{{ $order->id }}" tabindex="-1" role="dialog" aria-labelledby="modalRating{{ $order->id }}label" aria-hidden="true">
								  <div class="modal-dialog">
								    <div class="modal-content">
								      <div class="modal-header">
								        <h5 class="modal-title" id="modalRating{{ $order->id }}label">Rating:</h5>
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								          <span aria-hidden="true">&times;</span>
								        </button>
								      </div>
								      <div class="modal-body">
        								<div class="form-group">
          									<label> Bagaimana perjalanan Anda?</label>
          									<select class="form-control" name="rating">
          										<option>1</option>
          										<option>2</option>
          										<option>3</option>
          										<option>4</option>
          										<option>5</option>
          									</select>
								     	 </div>
								     	</div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-secondary" data-dismiss="modal">Kembali</button>

								        {{-- SPAN ID TOMBOL SUBMIT --}}
								        <span id="hapus-button">
								        		<button type="submit" class="btn btn-success">Submit</button>
								        </span>

								      </div>
								    </div>
								  </div>
								</div>
							</form>
							{{-- <a href="" class="badge badge-success">edit</a> --}}
							<form name="form-batal" id="form-batal" action="/pesan/hapus/{{ $order -> id }}" method="POST">
								@csrf
								<!-- Modal -->
								<div class="modal fade" id="modal-hapus-{{ $order->id }}" tabindex="-1" role="dialog" aria-labelledby="modalHapus{{ $order->id }}label" aria-hidden="true">
								  <div class="modal-dialog">
								    <div class="modal-content">
								      <div class="modal-header">
								        <h5 class="modal-title" id="modalHapus{{ $order->id }}label">Anda yakin ingin membatalkan pesanan? (Anda akan dikenakan Refund)</h5>
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								          <span aria-hidden="true">&times;</span>
								        </button>
								      </div>
								      <div class="modal-body">
        								<div class="form-group">
          									<label> Pilihan Refund:</label>
          									<div class="form-check">
            									<input type="radio" class="form-check-input" name="radio1" id="radio1">
          										<label>hanya 30% dari harga</label>
          									</div>

          									<div class="form-check">
							            		<input type="radio" class="form-check-input" name="radio2" id="radio2">
							          			<label>pengembalian via atm paling cepat 1 bulan</label>
							          		</div>
						    			</div>
							     	 </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-secondary" data-dismiss="modal">Kembali</button>
								        <button type="submit" class="btn btn-danger">Batalkan Pesanan</button>
								      </div>
								    </div>
								  </div>
								</div>
							</form>


						</td>
					</tr>
					@endforeach
				</tbody>
				</table>
			</div>
		</div>
    </div>
@endsection






	{{-- <div class="container">
		<div class="row">
			<div class="col-6">
				<h1 class="mt-3 ">Pesanan Saya</h1>
				<!--memunculkan status setelah ditambahkan-->
				@if (session('status'))
    				<div class="alert alert-success">
        					{{ session('status') }}
   					 </div>
				@endif
				<ul class="list-group">
					@foreach($drivers as $driver)
				  	<li class="list-group-item d-flex justify-content-between align-items-center">
				    	{{ $driver->nama }}

				    	<!--<a href="/students/1" class="badge badge-info">detail</a> nanti pas mencet detail yang keluar yg id nya 1 walaupun mencetnya detail untuk orang id ke 2 sehingga salah-->

				    	<a href="/students/{{ $driver->id }}" class="badge badge-info">detail</a>
				  	</li>
				  	@endforeach
				</ul>
			</div>
		</div>
    </div> --}}
