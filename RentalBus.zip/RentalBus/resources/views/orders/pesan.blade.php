@extends('layout.main')

@section('title', 'Pesan Tiket Bus')

@section('container') 
  <div class="container">
    <div class="row">
      <div class="col-8">
        <h1 class="mt-3 ">Pesan Tiket Bus</h1>

          <!-- form method post dan action diarahkan ke post(/pesan)-->

        <form method="POST" action="/pesan">
          @csrf
          <div class="form-group">
            <label for="tujuan">Tujuan</label>

            <!-- id nyambung ke label, harus pake name!-->
            <!-- error digunakan buat data yg kosong-->

            {{-- <input type="text" class="form-control " id="tujuan" placeholder="Masukkan Tujuan Wisata..." name="tujuan"> --}}
            <select class="form-control" id="tujuan" name="tujuan">
              <option value="" disabled selected>Pilih tujuan</option>
              @foreach($rentals as $rental)
              <option value="{{ $rental->id }}">{{ $rental->tujuan }}, Bus {{ $rental->nama_bus }}, Rp. {{ $rental->harga }}/kursi, {{ $rental->jum_kursi }} kursi</option>
              @endforeach
            </select>
            


          <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <!-- id nyambung ke label, harus pake name!-->
            <input type="date" class="form-control center" id="tanggal" placeholder="Masukkan Tanggal..." name="tanggal">
          </div>


          <div class="form-group">
            <label for="jum_kursi_pesan">Jumlah Kursi</label>
            <!-- id nyambung ke label, harus pake name!-->
            <input type="text" class="form-control" id="jum_kursi_pesan" placeholder="Masukkan Jumlah Kursi" name="jum_kursi_pesan">
          </div>

          <button type="submit" class="btn btn-warning" >
            <svg width="1.2em" height="2em" viewBox="0 0 16 16" class="bi bi-search" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" d="M10.442 10.442a1 1 0 0 1 1.415 0l3.85 3.85a1 1 0 0 1-1.414 1.415l-3.85-3.85a1 1 0 0 1 0-1.415z"/>
            <path fill-rule="evenodd" d="M6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11zM13 6.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0z"/>
            </svg>  Cari</button>

        </form>             
            </div>
        </div>
    </div>
    </div>
@endsection