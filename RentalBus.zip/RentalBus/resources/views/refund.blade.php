@extends('layout.main')

@section('title', 'Refund')

@section('container')
  <body>
    <div class="container">
      <h2 class="alert alert-primary text-center">FORMULIR REFUND PERJALANAN</h2>

      <form>
        <div class="form-group">
          <label> Pilihan Refund</label>
          <div class="form-check">
            <input type="radio" class="form-check-input" name="radio1" id="radio2">
          <label>hanya 30% dari harga</label>

          <div class="form-check">
            <input type="radio" class="form-check-input" name="radio1" id="radio2">
          <label>pengembalian via atm paling cepat 1 bulan</label>
          </div>
    </div>
    
    <button type="submit" class="btn btn-primary">IYA</button>
    <button type="submit" class="btn btn-danger">TIDAK</button>
  </body>
@endsection
</html>