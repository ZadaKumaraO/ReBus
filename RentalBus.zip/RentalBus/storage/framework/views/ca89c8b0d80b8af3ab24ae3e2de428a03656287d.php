

<?php $__env->startSection('title', 'Pesanan Saya'); ?>

<?php $__env->startSection('container'); ?>

	
	<script type="text/javascript">
		// $(document).ready(function()
		// {
		// 	$("#hapus-button").click(function() 
		// 		{
		// 			$("#ratingbutton").hide();
		// 		});
		// });

	</script>

	<div class="container">
		<div class="row">
			<div class="col-10">
				<h1 class="mt-2">Pesanan Saya</h1>

				<table class="table">
				<thead class="thead-dark">
					<tr>
						<th scope="col">No.Pesanan</th>
						<th scope="col">Tujuan</th>
						<th scope="col">Nama Bus</th>
						<th scope="col">Harga</th>
						<th scope="col">Tanggal</th>
						<th scope="col">Jumlah Kursi  yang Dipesan </th>
						<th scope="col">Rating</th>
						<th scope="col">Aksi</th>
					</tr>
				</thead>
				<tbody>
					<!-- mengambil data dari tabel (variable $mahasiswa di singkat jadi $mhs)-->
					<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<!-- loop-> iteration pengganti int++ (biar nomor otomatis bertambah)-->
						<th scope="row"><?php echo e($order -> id); ?></th>
						<td><?php echo e($order -> tujuan -> tujuan); ?></td>
						<td><?php echo e($order-> tujuan -> nama_bus); ?></td>
						<td><?php echo e($order -> harga); ?></td>
						<td><?php echo e($order -> tanggal); ?></td>
						<td><?php echo e($order -> jum_kursi_pesan); ?></td>
						<td><?php echo e($order -> rating); ?></td>
						<td>
							
							<a class="badge badge-info" href="/pesan/detail/<?php echo e($order->id); ?>">Detail</a>

							
							<?php if(is_null($order->rating)): ?>

							

							<button class="badge badge-danger" type="button" data-toggle="modal" data-target="#modal-hapus-<?php echo e($order->id); ?>">Batalkan Pesanan</button>

							

							
							<button class="badge badge-success" type="button" data-toggle="modal" data-target="#modal-rating-<?php echo e($order->id); ?>">Beri Penilaian</button>
							
							
							<?php else: ?>
							<form name="form-batal" id="form-batal" action="/pesan/hapus/<?php echo e($order -> id); ?>" method="POST">

							<button class="badge badge-secondary" type="button" disabled>Pesanan Telah Selesai</button>
							<button class="badge badge-danger" type="submit">Hapus Riwayat Pesan</button>

							<?php endif; ?>

							<form name="form-rating" id="form-rating" action="/pesan/rating/<?php echo e($order -> id); ?>" method="POST">
								<?php echo csrf_field(); ?>
								<!-- Modal -->
								<div class="modal fade" id="modal-rating-<?php echo e($order->id); ?>" tabindex="-1" role="dialog" aria-labelledby="modalRating<?php echo e($order->id); ?>label" aria-hidden="true">
								  <div class="modal-dialog">
								    <div class="modal-content">
								      <div class="modal-header">
								        <h5 class="modal-title" id="modalRating<?php echo e($order->id); ?>label">Rating:</h5>
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								          <span aria-hidden="true">&times;</span>
								        </button>
								      </div>
								      <div class="modal-body">
        								<div class="form-group">
          									<label> Bagaimana perjalanan Anda?</label>
          									<select class="form-control" name="rating">
          										<option>1</option>
          										<option>2</option>
          										<option>3</option>
          										<option>4</option>
          										<option>5</option>
          									</select>
								     	 </div>
								     	</div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-secondary" data-dismiss="modal">Kembali</button>

								        
								        <span id="hapus-button">
								        		<button type="submit" class="btn btn-success">Submit</button>
								        </span>

								      </div>
								    </div>
								  </div>
								</div>
							</form>
							
							<form name="form-batal" id="form-batal" action="/pesan/hapus/<?php echo e($order -> id); ?>" method="POST">
								<?php echo csrf_field(); ?>
								<!-- Modal -->
								<div class="modal fade" id="modal-hapus-<?php echo e($order->id); ?>" tabindex="-1" role="dialog" aria-labelledby="modalHapus<?php echo e($order->id); ?>label" aria-hidden="true">
								  <div class="modal-dialog">
								    <div class="modal-content">
								      <div class="modal-header">
								        <h5 class="modal-title" id="modalHapus<?php echo e($order->id); ?>label">Anda yakin ingin membatalkan pesanan? (Anda akan dikenakan Refund)</h5>
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								          <span aria-hidden="true">&times;</span>
								        </button>
								      </div>
								      <div class="modal-body">
        								<div class="form-group">
          									<label> Pilihan Refund:</label>
          									<div class="form-check">
            									<input type="radio" class="form-check-input" name="radio1" id="radio1">
          										<label>hanya 30% dari harga</label>
          									</div>

          									<div class="form-check">
							            		<input type="radio" class="form-check-input" name="radio2" id="radio2">
							          			<label>pengembalian via atm paling cepat 1 bulan</label>
							          		</div>
						    			</div>
							     	 </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-secondary" data-dismiss="modal">Kembali</button>
								        <button type="submit" class="btn btn-danger">Batalkan Pesanan</button>
								      </div>
								    </div>
								  </div>
								</div>
							</form>


						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
				</table>
			</div>
		</div>
    </div>
<?php $__env->stopSection(); ?>






	

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\RentalBus\resources\views/orders/riwayat.blade.php ENDPATH**/ ?>