

<?php $__env->startSection('title', 'Pesan Tiket Bus'); ?>

<?php $__env->startSection('container'); ?> 
  <div class="container">
    <div class="row">
      <div class="col-8">
        <h1 class="mt-3 ">Pesan Tiket Bus</h1>

          <!-- form method post dan action diarahkan ke post(/pesan)-->

        <form method="POST" action="/pesan">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="tujuan">Tujuan</label>

            <!-- id nyambung ke label, harus pake name!-->
            <!-- error digunakan buat data yg kosong-->

            
            <select class="form-control" id="tujuan" name="tujuan">
              <option value="" disabled selected>Pilih tujuan</option>
              <?php $__currentLoopData = $rentals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($rental->id); ?>"><?php echo e($rental->tujuan); ?>, Bus <?php echo e($rental->nama_bus); ?>, Rp. <?php echo e($rental->harga); ?>/kursi, <?php echo e($rental->jum_kursi); ?> kursi</option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            


          <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <!-- id nyambung ke label, harus pake name!-->
            <input type="date" class="form-control center" id="tanggal" placeholder="Masukkan Tanggal..." name="tanggal">
          </div>


          <div class="form-group">
            <label for="jum_kursi_pesan">Jumlah Kursi</label>
            <!-- id nyambung ke label, harus pake name!-->
            <input type="text" class="form-control" id="jum_kursi_pesan" placeholder="Masukkan Jumlah Kursi" name="jum_kursi_pesan">
          </div>

          <button type="submit" class="btn btn-warning" >
            <svg width="1.2em" height="2em" viewBox="0 0 16 16" class="bi bi-search" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" d="M10.442 10.442a1 1 0 0 1 1.415 0l3.85 3.85a1 1 0 0 1-1.414 1.415l-3.85-3.85a1 1 0 0 1 0-1.415z"/>
            <path fill-rule="evenodd" d="M6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11zM13 6.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0z"/>
            </svg>  Cari</button>

        </form>             
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\RentalBus\resources\views/orders/pesan.blade.php ENDPATH**/ ?>