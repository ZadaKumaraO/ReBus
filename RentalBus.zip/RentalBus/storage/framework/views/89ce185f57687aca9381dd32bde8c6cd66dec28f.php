

<?php $__env->startSection('title', 'Form Tambah Data Mahasiswa'); ?>

<?php $__env->startSection('container'); ?> 
  <div class="container">
    <div class="row">
      <div class="col-8">
        <h1 class="mt-3 ">Absensi Supir</h1>

          <!-- form method post dan action diarahkan ke POST(drivers)-->

        <form method="POST" action="/drivers">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="nama">Nama</label>

            <!-- id nyambung ke label, harus pake name!-->
            <!-- error digunakan buat data yg kosong-->

            <input type="text" class="form-control " id="nama" placeholder="Masukkan Nama.." name="nama">
            

          <div class="form-group">
            <label for="id_driver">ID</label>
            <!-- id nyambung ke label, harus pake name!-->
            <input type="text" class="form-control" id="id_driver" placeholder="Masukkan id..." name="id_driver">
          </div>

          <div class="form-group">
            <label for="bus">Bus</label>
            <!-- id nyambung ke label, harus pake name!-->
            <input type="text" class="form-control" id="bus" placeholder="Masukkan Nama Bus..." name="bus">
          </div>

          <div class="form-group">
            <label for="tujuan">Tujuan</label>
            <!-- id nyambung ke label, harus pake name!-->
            <input type="text" class="form-control" id="tujuan" placeholder="Masukkan Tujuan..." name="tujuan">
          </div>

          <div class="form-group">
            <label for="ket">Keterangan</label>
            <!-- id nyambung ke label, harus pake name!-->
            <input type="text" class="form-control" id="ket" placeholder="Masukkan Keterangan..." name="ket">
          </div>

          <button type="submit" class="btn btn-primary" name="btnIn">Absen Masuk</button>
          <button type="submit" class="btn btn-primary" name="btnOut">Absen Keluar</button>

        </form>             
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\RentalBus\resources\views/drivers/create.blade.php ENDPATH**/ ?>