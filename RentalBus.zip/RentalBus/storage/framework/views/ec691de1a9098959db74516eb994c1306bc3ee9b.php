

<?php $__env->startSection('title', 'Detail Bus'); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
	<div class="card w-100 h-100">
	  <div class="row no-gutters">
	    <div class="col-md-4">
	    	
	      <img src="<?php echo e(asset($order->tujuan->foto)); ?>" class="card-img h-100 w-100" alt="..." style="object-fit: cover">
	    </div>
	    <div class="col-md-8">
	      <div class="card-body">
	        <h5 class="card-title">Nama Bus: <?php echo e($order->tujuan->nama_bus); ?></h5>
	        <h5 class="card-title">Nama Sopir: <?php echo e($order->tujuan->nama_sopir); ?></h5>
	        <h5 class="card-title">Harga:Rp. <?php echo e($order->tujuan->harga); ?>/kursi </h5>
	        <h5 class="card-title">Jumlah Kursi: <?php echo e($order->tujuan->jum_kursi); ?></h5>
	        
	        <p class="card-text"><small class="text-muted">Tanggal: <?php echo e($order->tanggal); ?></small></p>
	      </div>
	    </div>
	  </div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\RentalBus\resources\views/orders/detail.blade.php ENDPATH**/ ?>