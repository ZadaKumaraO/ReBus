Cara Membuka Website ReBus:

1. Extract file ReBus ke \XAMPP\htdocs
2. Jangan lupa import database (rentalbus.sql) ke localhost
3. Buka console command, ganti route dari c: ke file ReBus yang disimpan.
4. Ketik "php artisan serve"
5. Salin dan tempel alamat servernya di browser
6. Anda telah membuka website ReBus

Cara Menggunakan Website (Setelah melakukan 6 langkah di atas):
1. Pada halaman awal, anda dapat memesan tiket dengan 2 cara, yaitu dengan cara menekan tombol klik disini yang berwarna hijau atau mengklik "Pesan Tiket" di navigasi
2. Akan muncul halaman pesan tiket bus, pilih tujuan yang diinginkan, pilih tanggal pemesanan, dan ketik jumlah kursi yang diinginkan. (Note: Hanya dapat memilih tujuan yang ada di dropdown list, selain dari dropdown tidak bisa).
3.Setelah itu, klik tombol cari untuk memesannya.
4. Berhasil memesan / merental bus
5. Anda bisa melihat pesanan dengan cara mengklik "Pesanan Saya" di tab navigasi
6. Bila ingin melihat detail dari pesanan, maka dapat mengklik tombol detail.
7. Akan muncul halaman detail pesanan. Halaman tersebut terdiri dari foto bus, nama bus, nama sopir, harga per kursi, dan jumlah kursi
8. Bila ingin keluar dari halaman detail pesanan, tinggal mengklik tombol yang ada di tab navigasi
9. Bila ingin membatalkan pesanan, maka klik tombol "Batalkan pesanan"
10. Akan muncul pop up refund, ada pilihan refund, pilih salah satu , setelah itu pencet tombol "Batalkan Pesanan"
11. Bila pesanan telah selesai, tekan tombol "Beri penilaian" untuk memberi rating perjalanan anda.
12. Akan muncul pop up rating, pilih rating yang sesuai, setelah itu submit
13. Di tab navigasi juga ada tombol "Tentang Kami", yang berisi foto dan nama pembuat website.
14. Bila menekan logo, akan kembali ke halaman awal