<?php

namespace App\Http\Controllers;

use App\Order;
use App\Rental;
use Illuminate\Http\Request;

class OrdersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    //return untuk pesan tiket
    public function index()
    {
        return view('orders.pesan', [
            'rentals' => Rental::all()
        ]);
    }

    public function detail($id){
        $order = Order::find($id);
        return view('orders.detail', compact('order'));
    }

    public function riwayat()
    {
        $orders = Order::all();
        $rentals = Rental::all();
        return view('orders.riwayat', [
            'orders' => $orders,
            'rentals' => $rentals
        ]);

    }

    public function rating(Request $request, $id)
    {
        $order = Order::find($id);

        //membuat data baru (insert data rating).
        $order->rating = $request->rating;
        $order->save();

        return redirect()->back();
    }
    //metode untuk menampilkan hasil pencarian pesan tiket
    // public function hasil_cari()
    // {
    //     $rentals = rental::all();
    //     return view('rentals.index', compact('rentals'));
    // }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //find = mencari baris yg ditunjuk pake idnya
        $tujuan = Rental::find($request->tujuan);
        $hargaTotal = $tujuan->harga * $request->jum_kursi_pesan;

        //membuat data baru (insert data).
        Order::create([
            'id_tujuan' => $request->tujuan, 
            'harga' => $hargaTotal, 
            'tanggal' => $request->tanggal, 
            'jum_kursi_pesan' => $request->jum_kursi_pesan
        ]);

        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function show(Order $order)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function edit(Order $order)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Order $order)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        $order = Order::find($id)->delete();
        return redirect()->back();
    }
}
