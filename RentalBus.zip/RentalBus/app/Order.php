<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
	protected $fillable = ['id_tujuan', 'harga', 'tanggal', 'jum_kursi_pesan'];

	//nyambungin orders ke rentals.. jadi kalo mau make rentals yang tersambung dengan orders, tinggal $order->tujuan->[nama atribut tujuan]
    public function tujuan(){
    	return $this->belongsTo('App\Rental', 'id_tujuan');
    }
}
