<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Tes Card doang
//Route::get('/', 'DriversController@test');

//Halaman Awal
Route::get('/', 'PagesController@home');
//Halaman Tentang Kita
Route::get('/about', 'PagesController@about');

//Halaman Cari
Route::get('/pesan','OrdersController@index');
//menyimpan pesanan
Route::post('/pesan', 'OrdersController@store');

//Halaman Hasil Pencarian
Route::get('/pesan/hasil','RentalsController@index');

//Halaman Riwayat Pesan
Route::get('/pesan/riwayat','OrdersController@riwayat');

//Halaman Detail Bus
Route::get('/pesan/detail/{id}','OrdersController@detail');

//Buat rating
Route::post('/pesan/rating/{id}','OrdersController@rating');

//Buat hapus data
Route::post('/pesan/hapus/{id}','OrdersController@destroy');
